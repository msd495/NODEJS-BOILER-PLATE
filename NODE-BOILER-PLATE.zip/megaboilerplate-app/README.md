1)Install and start mongodb server first.
2)Do npm install in same directory
3)run node server.js
4)Frontend developer has to change in public folder.